CREATE TABLE SCORE(
    id INTEGER auto_increment NOT NULL,
    vitorias INTEGER NOT NULL,
    derrotas INTEGER NOT NULL,
    empates INTEGER NOT NULL,
    PRIMARY KEY(id)

);